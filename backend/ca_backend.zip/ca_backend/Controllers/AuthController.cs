﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ca_backend.Data;
using ca_backend.Models;
using BCrypt.Net;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.AspNetCore.Authorization;

namespace ca_backend.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly IConfiguration _configuration;

    public AuthController(AppDbContext context, IConfiguration configuration)
    {
        _context = context;
        _configuration = configuration;
    }

    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginDto loginDto)
    {
        if (string.IsNullOrEmpty(loginDto.Email) || string.IsNullOrEmpty(loginDto.Password))
        {
            return BadRequest("Email and password are required.");
        }

        // Find user by email
        var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == loginDto.Email);

        if (user == null || !BCrypt.Net.BCrypt.Verify(loginDto.Password, user.Password))
        {
            return Unauthorized("Invalid email or password.");
        }

        // Check passwordchanges for this email
        var passwordChange = await _context.PasswordChanges.FirstOrDefaultAsync(pc => pc.Email == loginDto.Email);
        bool isChanged = passwordChange?.IsChanged ?? false;

        // Get JWT configuration
        var jwtKey = _configuration["Jwt:Key"];
        var jwtIssuer = _configuration["Jwt:Issuer"];
        var jwtAudience = _configuration["Jwt:Audience"];

        if (string.IsNullOrEmpty(jwtKey) || string.IsNullOrEmpty(jwtIssuer) || string.IsNullOrEmpty(jwtAudience))
        {
            return StatusCode(500, "JWT configuration is missing. Please check appsettings.json.");
        }

        // Generate JWT token (no expiry)
        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, user.Email),
            new Claim(ClaimTypes.NameIdentifier, user.Email),
            new Claim(ClaimTypes.Role, user.Role),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
        };

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var token = new JwtSecurityToken(
            issuer: jwtIssuer,
            audience: jwtAudience,
            claims: claims,
            signingCredentials: creds
        );

        var tokenString = new JwtSecurityTokenHandler().WriteToken(token);

        return Ok(new
        {
            isPasswordChanged = isChanged,
            token = tokenString,
            role = user.Role
        });
    }

    [HttpPost("staff-login")]
    public async Task<IActionResult> StaffLogin([FromBody] LoginDto loginDto)
    {
        if (string.IsNullOrEmpty(loginDto.Email) || string.IsNullOrEmpty(loginDto.Password))
        {
            return BadRequest("Email and password are required.");
        }

        // Find user by email
        var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == loginDto.Email);

        if (user == null || !BCrypt.Net.BCrypt.Verify(loginDto.Password, user.Password))
        {
            return Unauthorized("Invalid email or password.");
        }

        // Restrict to staff or intern roles
        if (user.Role != "staff" && user.Role != "intern")
        {
            return StatusCode(403, "Only staff or interns can use this login endpoint.");
        }

        // Check or create passwordchanges entry
        var passwordChange = await _context.PasswordChanges.FirstOrDefaultAsync(pc => pc.Email == loginDto.Email);
        bool isChanged = passwordChange?.IsChanged ?? false;
        if (passwordChange == null)
        {
            try
            {
                _context.PasswordChanges.Add(new PasswordChange
                {
                    Email = user.Email,
                    IsChanged = false
                });
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                return StatusCode(500, "An error occurred while creating password change entry.");
            }
        }

        // Get JWT configuration
        var jwtKey = _configuration["Jwt:Key"];
        var jwtIssuer = _configuration["Jwt:Issuer"];
        var jwtAudience = _configuration["Jwt:Audience"];

        if (string.IsNullOrEmpty(jwtKey) || string.IsNullOrEmpty(jwtIssuer) || string.IsNullOrEmpty(jwtAudience))
        {
            return StatusCode(500, "JWT configuration is missing. Please check appsettings.json.");
        }

        // Generate JWT token (no expiry)
        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, user.Email),
            new Claim(ClaimTypes.NameIdentifier, user.Email),
            new Claim(ClaimTypes.Role, user.Role),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
        };

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var token = new JwtSecurityToken(
            issuer: jwtIssuer,
            audience: jwtAudience,
            claims: claims,
            signingCredentials: creds
        );

        var tokenString = new JwtSecurityTokenHandler().WriteToken(token);

        return Ok(new
        {
            isPasswordChanged = isChanged,
            token = tokenString,
            role = user.Role
        });
    }

    [Authorize]
    [HttpPost("change-password")]
    public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordDto changePasswordDto)
    {
        if (string.IsNullOrEmpty(changePasswordDto.CurrentPassword) || string.IsNullOrEmpty(changePasswordDto.NewPassword))
        {
            return BadRequest("Current password and new password are required.");
        }

        // Extract email from JWT token claims
        var email = User.FindFirstValue(JwtRegisteredClaimNames.Sub) ?? User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (string.IsNullOrEmpty(email))
        {
            var claims = User.Claims.Select(c => $"{c.Type}: {c.Value}").ToList();
            Console.WriteLine("Claims: " + string.Join(", ", claims));
            return StatusCode(401, "Invalid token: No 'sub' or 'nameidentifier' claim found.");
        }

        // Find user by email from token
        var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == email);
        if (user == null)
        {
            return StatusCode(401, "User not found.");
        }

        // Verify current password
        if (!BCrypt.Net.BCrypt.Verify(changePasswordDto.CurrentPassword, user.Password))
        {
            return StatusCode(401, "Current password is incorrect.");
        }

        // Hash new password
        var hashedNewPassword = BCrypt.Net.BCrypt.HashPassword(changePasswordDto.NewPassword);

        try
        {
            // Update password in users table
            user.Password = hashedNewPassword;
            _context.Users.Update(user);

            // Update or create passwordchanges entry
            var passwordChange = await _context.PasswordChanges.FirstOrDefaultAsync(pc => pc.Email == email);
            if (passwordChange != null)
            {
                passwordChange.IsChanged = true;
                _context.PasswordChanges.Update(passwordChange);
            }
            else
            {
                _context.PasswordChanges.Add(new PasswordChange { Email = email, IsChanged = true });
            }

            await _context.SaveChangesAsync();

            return Ok(new
            {
                message = "Password changed successfully.",
                role = user.Role
            });
        }
        catch (DbUpdateException)
        {
            return StatusCode(500, "An error occurred while changing the password.");
        }
    }
}

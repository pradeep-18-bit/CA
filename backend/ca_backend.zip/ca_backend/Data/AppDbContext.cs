﻿using Microsoft.EntityFrameworkCore;
using ca_backend.Models;

namespace ca_backend.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<User> Users { get; set; }
    public DbSet<PasswordChange> PasswordChanges { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Map 'users' table
        modelBuilder.Entity<User>(entity =>
        {
            entity.ToTable("users");
            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.FirstName).HasColumnName("first_name");
            entity.Property(e => e.LastName).HasColumnName("last_name");
            entity.Property(e => e.Email).HasColumnName("email");
            entity.Property(e => e.MobileNumber).HasColumnName("mobile_number");
            entity.Property(e => e.Password).HasColumnName("password");
            entity.Property(e => e.Role).HasColumnName("role");
            entity.HasIndex(e => e.Email).IsUnique();
            entity.HasIndex(e => e.MobileNumber).IsUnique();
        });

        // Map 'passwordchanges' table
        modelBuilder.Entity<PasswordChange>(entity =>
        {
            entity.ToTable("passwordchanges");
            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Email).HasColumnName("email");
            entity.Property(e => e.IsChanged).HasColumnName("is_changed").HasDefaultValue(false);
            entity.HasIndex(e => e.Email).IsUnique();
        });
    }
}